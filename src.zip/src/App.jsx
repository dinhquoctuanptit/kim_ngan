import { useEffect, useRef, useState } from 'react'
import { createEngine } from './systems/SceneEngine.js'
import { GestureMachine } from './gestures/gestureStateMachine.js'
import { detectGesture, handDistance } from './gestures/gestureDetector.js'
import { useHandTracking } from './hooks/useHandTracking.js'
import { IMAGES, SPECIAL } from './utils/imageUtils.js'
import CameraIndicator from './components/CameraIndicator.jsx'
import GestureGuide from './components/GestureGuide.jsx'
import LoveEffect from './components/LoveEffect.jsx'

export default function App() {
  const mount = useRef(null), { videoRef, status, getHands } = useHandTracking(), [love, setLove] = useState(false), [gstate, setGstate] = useState('IDLE')
  useEffect(() => {
    const engine = createEngine(mount.current, { images: IMAGES, special: SPECIAL }), machine = new GestureMachine()
    let raf, last = performance.now(), loveNow = false, stNow = 'IDLE'
    const loop = (now) => {
      const dt = Math.min((now - last) / 1000, 0.05); last = now
      const hands = getHands(), ev = machine.update(detectGesture(hands), dt, { canSelect: engine.canSelect() })
      const isLove = machine.state === 'LOVE'; if (isLove !== loveNow) { loveNow = isLove; setLove(isLove) }
      if (machine.state !== stNow) { stNow = machine.state; setGstate(stNow) }
      engine.update(dt, machine.layout, isLove, machine.state === 'SPECIAL_IMAGE', handDistance(hands), ev)
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => { cancelAnimationFrame(raf); engine.dispose() }
  }, [getHands])
  return (<>
    <div className="stage" ref={mount} />
    <LoveEffect active={love} />
    <GestureGuide state={gstate} />
    <CameraIndicator videoRef={videoRef} status={status} />
  </>)
}
