const d = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, (a.z - b.z) * 0.5)
const size = (h) => d(h[0], h[9])
const ext = (h, tip, pip) => d(h[tip], h[0]) > d(h[pip], h[0]) * 1.12
function fingers(h) {
  return { t: d(h[4], h[17]) > d(h[3], h[17]) * 1.05, i: ext(h, 8, 6), m: ext(h, 12, 10), r: ext(h, 16, 14), p: ext(h, 20, 18) }
}
export function classifyHand(h) {
  const f = fingers(h), s = size(h)
  if (f.m && !f.i && !f.r && !f.p && d(h[4], h[9]) < s * 1.05) return 'MIDDLE'
  if (d(h[4], h[8]) < s * 0.45 && f.m && f.r && f.p) return 'OK'
  if (f.i && f.m && f.r && f.p) return 'OPEN'
  if (!f.i && !f.m && !f.r && !f.p) return 'FIST'
  return 'OTHER'
}
// hands: mảng 0..2 bàn tay (mỗi bàn tay 21 landmark, đã mirror)
export function detectGesture(hands) {
  if (!hands.length) return 'NONE'
  if (hands.length === 1) return classifyHand(hands[0])
  const [a, b] = hands, s = (size(a) + size(b)) / 2
  const heart = d(a[8], b[8]) < s * 0.9 && d(a[4], b[4]) < s * 0.9 && a[8].y < a[4].y && b[8].y < b[4].y
  if (heart) return 'HEART'
  const ca = classifyHand(a), cb = classifyHand(b)
  if (ca === 'FIST' && cb === 'FIST') return 'FIST'
  return 'TWO' // hai tay: dùng để thu phóng, không kích hoạt thao tác khác
}
export const handDistance = (hands) => (hands.length === 2 ? d(hands[0][9], hands[1][9]) : null)
