import { CONFIRM, LOST_FRAMES } from './gestureConfig.js'
const SCATTERED = ['EXPLODE', 'SUMMON_IMAGES', 'IMAGE_SELECTION', 'IMAGE_SELECTED', 'IMAGE_ZOOM']
export class GestureMachine {
  constructor() { this.state = 'IDLE'; this.back = 'IDLE'; this.cand = 'NONE'; this.n = 0; this.stable = 'NONE'; this.timer = 0; this.okFired = false }
  get layout() { return this.state === 'LOVE' || this.state === 'SPECIAL_IMAGE' ? this.back : this.state }
  update(g, dt, ctx) {
    const ev = []
    this.n = g === this.cand ? this.n + 1 : 1; this.cand = g
    const need = g === 'NONE' ? LOST_FRAMES : CONFIRM[g] || 4
    let edge = false
    if (this.n >= need && this.stable !== g) { this.stable = g; edge = true }
    const s = this.stable, st = this.state, go = (x) => { this.state = x; this.timer = 0 }
    this.timer += dt
    if (s !== 'OK') this.okFired = false
    if (st === 'SPECIAL_IMAGE') { if (edge && s !== 'MIDDLE') go(this.back) }
    else if (st === 'LOVE') { if (edge && s !== 'HEART') go(this.back) }
    else if (edge && s === 'MIDDLE') { this.back = st; go('SPECIAL_IMAGE') }
    else if (edge && s === 'HEART' && st !== 'IMAGE_SELECTED' && st !== 'IMAGE_ZOOM') { this.back = st; go('LOVE') }
    else if (edge && s === 'OPEN' && (st === 'IMAGE_SELECTED' || st === 'IMAGE_ZOOM')) { ev.push('dismiss'); go('IMAGE_SELECTION') }
    else if (edge && s === 'OPEN' && (st === 'IDLE' || st === 'GATHER')) go('EXPLODE')
    else if (edge && s === 'FIST' && st !== 'IDLE') { ev.push('dismiss'); go('GATHER') }
    else if (st === 'IMAGE_SELECTION' && s === 'OK' && !this.okFired && ctx.canSelect) { this.okFired = true; ev.push('select'); go('IMAGE_SELECTED') }
    // chuyển cảnh theo thời gian
    const t = this.timer
    if (this.state === 'EXPLODE' && t > 0.9) go('SUMMON_IMAGES')
    else if (this.state === 'SUMMON_IMAGES' && t > 0.6) go('IMAGE_SELECTION')
    else if (this.state === 'IMAGE_SELECTED' && t > 1.2) go('IMAGE_ZOOM')
    else if (this.state === 'GATHER' && t > 1.8) go('IDLE')
    return ev
  }
}
export const isScattered = (layout) => SCATTERED.includes(layout)
