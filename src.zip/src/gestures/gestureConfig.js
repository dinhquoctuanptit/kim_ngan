export const SPECIAL_IMAGE = 'love.jpg' // tên file trong src/assets/special-images/ (không có -> dùng ảnh đầu tiên)
export const MAX_BIG = 5
// số frame liên tiếp cần giữ cử chỉ để xác nhận
export const CONFIRM = { OPEN: 5, FIST: 5, OK: 4, MIDDLE: 8, HEART: 6, TWO: 3 }
export const LOST_FRAMES = 20
