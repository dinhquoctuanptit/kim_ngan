import { useEffect, useRef, useState, useCallback } from 'react'
const WASM = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm'
const MODEL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'
export function useHandTracking() {
  const videoRef = useRef(null), lm = useRef(null), last = useRef(-1), cache = useRef([]), [status, setStatus] = useState('loading')
  useEffect(() => {
    let stream
    ;(async () => {
      try {
        const { FilesetResolver, HandLandmarker } = await import('@mediapipe/tasks-vision')
        const fs = await FilesetResolver.forVisionTasks(WASM)
        const opts = (delegate) => ({ baseOptions: { modelAssetPath: MODEL, delegate }, runningMode: 'VIDEO', numHands: 2, minHandDetectionConfidence: 0.6, minTrackingConfidence: 0.6 })
        try { lm.current = await HandLandmarker.createFromOptions(fs, opts('GPU')) } catch { lm.current = await HandLandmarker.createFromOptions(fs, opts('CPU')) }
        stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480, facingMode: 'user' } })
        videoRef.current.srcObject = stream; await videoRef.current.play(); setStatus('ready')
      } catch (e) { setStatus(e && e.name === 'NotAllowedError' ? 'denied' : 'error') }
    })()
    return () => stream && stream.getTracks().forEach((t) => t.stop())
  }, [])
  const getHands = useCallback(() => {
    const v = videoRef.current
    if (!lm.current || !v || v.readyState < 2 || v.currentTime === last.current) return cache.current
    last.current = v.currentTime
    const res = lm.current.detectForVideo(v, performance.now())
    const raw = res.landmarks.map((h) => h.map((p) => ({ x: 1 - p.x, y: p.y, z: p.z }))).sort((a, b) => a[0].x - b[0].x)
    const prev = cache.current
    cache.current = raw.map((h, k) => (prev.length === raw.length ? h.map((p, i) => ({ x: prev[k][i].x * 0.45 + p.x * 0.55, y: prev[k][i].y * 0.45 + p.y * 0.55, z: prev[k][i].z * 0.45 + p.z * 0.55 })) : h))
    return cache.current
  }, [])
  return { videoRef, status, getHands }
}
