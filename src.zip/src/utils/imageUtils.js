import { SPECIAL_IMAGE } from '../gestures/gestureConfig.js'
// Vite yêu cầu glob là chuỗi literal. '**' = đọc cả các thư mục con (vd: images/anh_nguoi/)
const normal = import.meta.glob('../assets/images/**/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, query: '?url', import: 'default' })
const special = import.meta.glob('../assets/special-images/**/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, query: '?url', import: 'default' })
export const IMAGES = Object.entries(normal).map(([p, url]) => ({ id: p, url }))
const sp = Object.entries(special).map(([p, url]) => ({ id: p, url }))
export const SPECIAL = sp.find((s) => s.id.split('/').pop() === SPECIAL_IMAGE) || sp[0] || null
