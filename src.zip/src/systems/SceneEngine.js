import * as THREE from 'three'
import { ImageQueue } from './ImageQueue.js'
import { isScattered } from '../gestures/gestureStateMachine.js'
import { MAX_BIG } from '../gestures/gestureConfig.js'
import glassUrl from '../assets/hearts/glass-heart.png'
import neonUrl from '../assets/hearts/neon-heart.png'
import { clamp, rand, damp } from '../utils/mathUtils.js'

const VERT = `attribute float aSize;attribute vec3 aColor;attribute float aPhase;attribute float aE;attribute float aExtra;uniform float uTime,uGlow,uAlpha,uScale;varying vec3 vC;varying float vA;
void main(){vec4 mv=modelViewMatrix*vec4(position,1.);float tw=.5+.5*sin(uTime*(1.5+aPhase*2.)+aPhase*40.);float vis=mix(1.,smoothstep(.05,.45,aE),aExtra);
vC=aColor*(.55+.45*tw)*uGlow;vA=uAlpha*vis*(.6+.4*tw);gl_PointSize=aSize*vis*(1.+.9*aE)*uScale/-mv.z;gl_Position=projectionMatrix*mv;}`
const FRAG = `uniform sampler2D uMap;uniform float uTint,uGlow;varying vec3 vC;varying float vA;void main(){vec4 t=texture2D(uMap,vec2(gl_PointCoord.x,1.-gl_PointCoord.y));vec3 c=uTint>.5?vC:t.rgb*(.6+.4*vA)*uGlow;gl_FragColor=vec4(c,t.a*vA);}`

function heartSprite() {
  const c = document.createElement('canvas'); c.width = c.height = 64
  const x = c.getContext('2d'); x.shadowColor = '#fff'; x.shadowBlur = 3; x.fillStyle = '#fff'; x.beginPath()
  for (let i = 0; i <= 60; i++) { const t = (i / 60) * Math.PI * 2, px = 16 * Math.sin(t) ** 3, py = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t); i ? x.lineTo(32 + px * 1.6, 34 - py * 1.6) : x.moveTo(32 + px * 1.6, 34 - py * 1.6) }
  x.fill(); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t
}
function glowTex() {
  const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d')
  const g = x.createRadialGradient(64, 64, 20, 64, 64, 64); g.addColorStop(0, 'rgba(255,0,204,.9)'); g.addColorStop(.5, 'rgba(255,0,204,.25)'); g.addColorStop(1, 'rgba(255,0,204,0)')
  x.fillStyle = g; x.fillRect(0, 0, 128, 128); return new THREE.CanvasTexture(c)
}
const PINK = [new THREE.Color('#FFB6D9'), new THREE.Color('#FF00CC'), new THREE.Color('#FF1493'), new THREE.Color('#FFF5FA')]

function makePoints(N, sprite, sizeMin, sizeMax, tint = 1, additive = true, nBase = N) {
  const geo = new THREE.BufferGeometry(), pos = new Float32Array(N * 3), col = new Float32Array(N * 3), size = new Float32Array(N), ph = new Float32Array(N), eArr = new Float32Array(N), ex = new Float32Array(N)
  const c = new THREE.Color()
  for (let i = 0; i < N; i++) {
    c.copy(PINK[0]).lerp(PINK[1], Math.random()); if (Math.random() < 0.04) c.copy(PINK[3]); else if (Math.random() < 0.2) c.copy(PINK[2])
    col.set([c.r, c.g, c.b], i * 3); size[i] = rand(sizeMin, sizeMax) * (Math.random() < 0.04 ? 1.8 : 1); ph[i] = Math.random(); ex[i] = i >= nBase ? 1 : 0
  }
  const eAttr = new THREE.BufferAttribute(eArr, 1)
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); geo.setAttribute('aColor', new THREE.BufferAttribute(col, 3))
  geo.setAttribute('aSize', new THREE.BufferAttribute(size, 1)); geo.setAttribute('aPhase', new THREE.BufferAttribute(ph, 1))
  geo.setAttribute('aE', eAttr); geo.setAttribute('aExtra', new THREE.BufferAttribute(ex, 1))
  const mat = new THREE.ShaderMaterial({ vertexShader: VERT, fragmentShader: FRAG, transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    uniforms: { uTint: { value: tint }, uMap: { value: sprite }, uTime: { value: 0 }, uGlow: { value: 1 }, uAlpha: { value: 1 }, uScale: { value: 500 } } })
  const pts = new THREE.Points(geo, mat); pts.frustumCulled = false; return { pts, pos, mat, eArr, eAttr }
}

export function createEngine(container, { images, special }) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true }); renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
  container.appendChild(renderer.domElement)
  const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(50, 1, 0.1, 100); cam.position.z = 14
  const sprite = heartSprite(), plane = new THREE.PlaneGeometry(1, 1)
  const resize = () => { const w = container.clientWidth, h = container.clientHeight; renderer.setSize(w, h); cam.aspect = w / h; cam.updateProjectionMatrix()
    const s = h * renderer.getPixelRatio() * 0.5; layers.forEach((L) => (L.mat.uniforms.uScale.value = s)); floaters.mat.uniforms.uScale.value = s * 1.3 }

  // ---- trái tim 3D: bề mặt implicit thật, ít hạt nhỏ khi gom; nhân lên nhiều lần khi xòe tay ----
  const layers = [], S = 3.0, texLoader = new THREE.TextureLoader()
  const png = (u) => { const t = texLoader.load(u); t.colorSpace = THREE.SRGBColorSpace; return t }
  const F = (x, y, z) => { const a = x * x + 2.25 * y * y + z * z - 1; return a * a * a - x * x * z * z * z - 0.1125 * y * y * z * z * z }
  const dir = new THREE.Vector3()
  function heartPoint(inner) {
    dir.randomDirection(); let lo = 0, hi = 2
    for (let k = 0; k < 20; k++) { const r = (lo + hi) / 2; F(r * dir.x, r * dir.y, r * dir.z) < 0 ? (lo = r) : (hi = r) }
    const r = lo * (Math.random() < inner ? rand(0.75, 0.95) : rand(0.97, 1.0))
    return [dir.x * r * S, dir.z * r * S - 0.15, dir.y * r * S] // z của công thức là trục đứng
  }
  function makeLayer(nBase, nTotal, spr, smin, smax, tint, additive, inner, grow = 1) {
    const L = makePoints(nTotal, spr, smin, smax, tint, additive, nBase); L.n = nTotal
    L.home = new Float32Array(nTotal * 3); L.tgt = new Float32Array(nTotal * 3); L.e = new Float32Array(nTotal); L.rate = new Float32Array(nTotal); L.sd = new Float32Array(nTotal)
    for (let i = 0; i < nTotal; i++) {
      if (i < nBase) { const h = heartPoint(inner); L.home.set([h[0] * grow, h[1] * grow, h[2] * grow], i * 3) }
      else { const b = (i % nBase) * 3; L.home.set([L.home[b] + rand(-.03, .03), L.home[b + 1] + rand(-.03, .03), L.home[b + 2] + rand(-.03, .03)], i * 3) }
      const u = new THREE.Vector3().randomDirection().multiplyScalar(3 + Math.pow(Math.random(), 1.3) * 9); u.y *= 0.65
      L.tgt.set([u.x, u.y, u.z], i * 3); L.rate[i] = rand(0.7, 3); L.sd[i] = Math.random() * 100
    }
    scene.add(L.pts); layers.push(L); return L
  }
  const heart = makeLayer(1500, 6000, sprite, 0.22, 0.5, 1, true, 0.2)
  makeLayer(36, 36, png(glassUrl), 0.9, 1.3, 0, false, 0, 1.03) // hạt thủy tinh
  makeLayer(24, 24, png(neonUrl), 0.8, 1.2, 0, true, 0, 1.03)   // hạt neon
  const floaters = makePoints(450, sprite, 0.6, 1.6), fl = new Float32Array(450 * 4)
  for (let i = 0; i < 450; i++) { floaters.pos.set([rand(-11, 11), rand(-7, 7), rand(-4, 5)], i * 3); fl[i * 4] = rand(0.3, 1.2); fl[i * 4 + 1] = rand(-0.4, 0.4) }
  scene.add(floaters.pts)

  // ---- ảnh ----
  const loader = new THREE.TextureLoader(), items = new Map()
  const mkMesh = (tex) => { tex.colorSpace = THREE.SRGBColorSpace; const m = new THREE.Mesh(plane, new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthTest: false, depthWrite: false, toneMapped: false })); m.visible = false; m.scale.setScalar(0.001); scene.add(m); return m }
  images.forEach(({ id, url }) => loader.load(url, (tex) => { items.set(id, { id, m: mkMesh(tex), aspect: tex.image.width / tex.image.height, size: 0, target: new THREE.Vector3(), seed: Math.random() * 100, sp: rand(0.3, 0.65), role: 'hidden', small: rand(0.8, 1.25) }) }, undefined, () => {}))
  let spec = null
  if (special) loader.load(special.url, (tex) => { spec = { m: mkMesh(tex), aspect: tex.image.width / tex.image.height, size: 0 } }, undefined, () => {})
  const border = new THREE.Mesh(plane, new THREE.MeshBasicMaterial({ color: 0xff00cc, depthTest: false, depthWrite: false })), glow = new THREE.Mesh(plane, new THREE.MeshBasicMaterial({ map: glowTex(), transparent: true, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false }))
  border.visible = glow.visible = false; scene.add(border, glow)

  const rings = [[1, 0.9], [1.04, 0.35]].map(([k, o]) => { const pts = []; for (let i = 0; i < 160; i++) { const a = (i / 160) * Math.PI * 2; pts.push(new THREE.Vector3(Math.sin(a), 0.3, Math.cos(a))) }
    const r = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0xff2bd6, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false })); r.userData = { k, o }; r.position.z = 0.5; r.renderOrder = 1; scene.add(r); return r })
  let queue = null, wasScattered = false, selId = null, candidate = null, ringRot = 0, zoom = 1, zoomGoal = 1, fade = 1, glowK = 1, time = 0
  const pick = (it, big) => { it.target.set(big ? rand(-8.5, 8.5) : rand(-12, 12), big ? rand(-4, 4) : rand(-6.5, 6.5), big ? rand(-2, 4) : rand(-9, -1)); if (big && Math.abs(it.target.x) < 2 && Math.abs(it.target.y) < 1.6) it.target.x += (it.target.x < 0 ? -3 : 3) }
  const summon = () => {
    if (!items.size) return
    if (!queue || queue.all.length !== items.size) queue = new ImageQueue([...items.keys()], MAX_BIG); else queue.redraw()
    selId = null
    items.forEach((it) => { it.m.position.set(rand(-.5, .5), rand(-.5, .5), rand(-.5, .5)); pick(it, false) })
  }
  const dismiss = () => { if (selId && queue) { queue.release(selId); selId = null } }
  const select = () => { if (candidate && queue && !selId) { selId = candidate; queue.select(selId); candidate = null; zoom = zoomGoal = 1 } }

  function update(dt, layout, love, isSpecial, handDist, events) {
    time += dt
    const scattered = isScattered(layout)
    if (scattered && !wasScattered) summon(); wasScattered = scattered
    for (const ev of events) ev === 'select' ? select() : dismiss()
    fade = damp(fade, isSpecial ? 0 : 1, 4, dt); glowK = damp(glowK, love ? 1.5 : 0.85, 3, dt)
    // hạt trái tim
    const pulse = (1 + 0.04 * Math.sin(time * 3)) * (love ? 1.15 : 1)
    for (const L of layers) {
      const u = L.mat.uniforms, p = L.pos, { home, tgt, e, rate, sd } = L; u.uTime.value = time; u.uGlow.value = glowK; u.uAlpha.value = fade
      for (let i = 0, j = 0; i < L.n; i++, j += 3) {
        e[i] += ((scattered ? 1 : 0) - e[i]) * (1 - Math.exp(-rate[i] * dt)); const k = e[i], w = 0.03 + 0.5 * k, s = sd[i]; L.eArr[i] = k
        p[j] = home[j] * (1 - k) + tgt[j] * k + Math.sin(time * 0.9 + s) * w
        p[j + 1] = home[j + 1] * (1 - k) + tgt[j + 1] * k + Math.sin(time * 1.1 + s * 1.7) * w
        p[j + 2] = home[j + 2] * (1 - k) + tgt[j + 2] * k + Math.cos(time * 0.8 + s * 2.3) * w
      }
      L.pts.geometry.attributes.position.needsUpdate = true; L.eAttr.needsUpdate = true
      L.pts.rotation.y += dt * (scattered ? 0.15 : 0.45); L.pts.scale.setScalar(damp(L.pts.scale.x, pulse, 6, dt))
    }
    floaters.mat.uniforms.uTime.value = time
    // trái tim mini bay lơ lửng (LOVE)
    floaters.mat.uniforms.uAlpha.value = damp(floaters.mat.uniforms.uAlpha.value, love ? 1 : 0, 2.5, dt); floaters.mat.uniforms.uGlow.value = 1.4
    const fp = floaters.pos; for (let i = 0; i < 450; i++) { fp[i * 3 + 1] += fl[i * 4] * dt; fp[i * 3] += fl[i * 4 + 1] * dt; if (fp[i * 3 + 1] > 8) fp[i * 3 + 1] = -8 }
    floaters.pts.geometry.attributes.position.needsUpdate = true; floaters.pts.rotation.y += dt * 0.2

    // ảnh
    if (handDist != null && selId) zoomGoal = clamp(handDist * 3.2, 0.5, 2.4)
    zoom = damp(zoom, zoomGoal, 6, dt)
    // 5 ảnh lớn chạy trên vòng elip (carousel); ảnh nhỏ bay tự do
    const bigs = new Set(scattered && queue ? queue.bigs : []), bigItems = []
    ringRot += dt * 0.22
    const R = Math.min(7.5, cam.aspect * 4.6), RZ = 4.5, Z0 = 0.5
    if (scattered && queue) { // mỗi ảnh lớn giữ một "ô" cố định trên vòng, ảnh mới vào đúng ô trống
      const taken = new Set(); items.forEach((it) => { if (bigs.has(it.id) && it.slot != null) taken.add(it.slot); else it.slot = null })
      for (const id of queue.bigs) { const it = items.get(id); if (it && it.slot == null) { let k = 0; while (taken.has(k)) k++; it.slot = k; taken.add(k) } }
    }
    items.forEach((it) => {
      const wantRole = !scattered || !queue ? 'hidden' : it.id === selId ? 'sel' : bigs.has(it.id) ? 'big' : 'small'
      if (it.role === 'hidden' && wantRole !== 'hidden') { it.m.visible = true; pick(it, false) }
      it.role = wantRole; const m = it.m; let fw = 0, th = 0, depth = 0.5
      if (wantRole === 'big') {
        bigItems.push(it); const ang = ringRot + (it.slot || 0) * 2 * Math.PI / MAX_BIG
        th = Math.atan2(Math.sin(ang), Math.cos(ang)); it.th = th; depth = (Math.cos(ang) + 1) / 2
        fw = clamp((Math.cos(ang) - 0.8) / 0.2, 0, 1)
        it.target.set(R * Math.sin(ang), 0.3 + Math.sin(time * 0.8 + it.seed) * 0.15, Z0 + RZ * Math.cos(ang))
      }
      const goal = wantRole === 'sel' ? 4.6 * zoom : wantRole === 'big' ? 2.2 + 1.3 * fw : wantRole === 'small' ? it.small : 0
      it.size = damp(it.size, goal, wantRole === 'sel' ? 5 : 3, dt)
      if (wantRole === 'sel') m.position.lerp(new THREE.Vector3(0, 0, 5), 1 - Math.exp(-4 * dt))
      else if (wantRole === 'hidden') m.position.lerp(new THREE.Vector3(0, 0, 0), 1 - Math.exp(-3 * dt))
      else if (wantRole === 'big') m.position.lerp(it.target, 1 - Math.exp(-5 * dt))
      else { m.position.lerp(it.target, 1 - Math.exp(-it.sp * dt)); if (m.position.distanceTo(it.target) < 0.5) pick(it, false)
        m.position.x += Math.sin(time * 0.7 + it.seed) * 0.4 * dt; m.position.y += Math.cos(time * 0.6 + it.seed) * 0.4 * dt }
      m.scale.set(it.size * it.aspect, it.size, 1)
      if (wantRole === 'big') { // ở giữa: chính diện tuyệt đối; hai bên nghiêng nhẹ vào trong như ảnh mẫu
        const f2 = clamp((0.45 - Math.abs(th)) / 0.25, 0, 1); m.rotation.set(0, -clamp(th, -1.2, 1.2) * 0.55 * (1 - f2), 0)
      } else if (wantRole === 'sel') m.rotation.set(0, 0, 0)
      else m.rotation.set(0, Math.sin(time * 0.6 + it.seed) * 0.4, Math.sin(time * 0.4 + it.seed) * 0.08)
      m.material.opacity = wantRole === 'sel' ? 1 : fade * (wantRole === 'big' ? 0.5 + 0.5 * depth : 1)
      m.renderOrder = wantRole === 'sel' ? 900 : Math.floor((m.position.z + 20) * 10)
      if (wantRole === 'hidden' && it.size < 0.02) m.visible = false
    })
    let best = null, bd = 0.28; for (const it of bigItems) { const d = Math.abs(it.th); if (d < bd) { bd = d; best = it } }
    candidate = best ? best.id : null
    const ringOn = scattered && !isSpecial
    for (const r of rings) { r.scale.set(R * r.userData.k, 1, RZ * r.userData.k); r.material.opacity = damp(r.material.opacity, ringOn ? r.userData.o : 0, 3, dt) }
    // ảnh đặc biệt
    let framed = null
    if (spec) {
      spec.size = damp(spec.size, isSpecial ? 5.6 : 0, 4, dt); spec.m.visible = spec.size > 0.02
      spec.m.position.set(0, 0, 6); spec.m.scale.set(spec.size * spec.aspect, spec.size, 1); spec.m.rotation.set(0, Math.sin(time * 0.9) * 0.35, 0); spec.m.renderOrder = 1000; if (spec.m.visible) framed = spec.m
    }
    if (!framed && selId) framed = items.get(selId)?.m
    border.visible = glow.visible = !!framed
    if (framed) {
      border.position.copy(framed.position); glow.position.copy(framed.position); border.rotation.copy(framed.rotation); glow.rotation.copy(framed.rotation)
      border.scale.set(framed.scale.x + 0.22, framed.scale.y + 0.22, 1); glow.scale.set(framed.scale.x * 1.7 + 1, framed.scale.y * 1.7 + 1, 1)
      border.renderOrder = framed.renderOrder - 1; glow.renderOrder = framed.renderOrder - 2; glow.material.opacity = 0.75 + 0.25 * Math.sin(time * 3)
    }
    renderer.render(scene, cam)
  }
  resize(); addEventListener('resize', resize)
  return {
    update, canSelect: () => !!candidate && !selId,
    dispose() { removeEventListener('resize', resize); scene.traverse((o) => { o.geometry?.dispose(); const m = o.material; m && (m.map?.dispose(), m.dispose()) }); sprite.dispose(); renderer.dispose(); renderer.domElement.remove() }
  }
}
