import { shuffle } from '../utils/mathUtils.js'
// Ảnh xuất hiện trong nhóm 5 ảnh lớn => đánh dấu "đã dùng" (rút khỏi pool) tới hết chu kỳ.
export class ImageQueue {
  constructor(ids, max = 5) { this.all = [...ids]; this.max = max; this.busy = new Set(); this.pool = shuffle([...ids]); this.bigs = []; this.fill() }
  fill() {
    while (this.bigs.length < this.max && this.bigs.length + this.busy.size < this.all.length) {
      if (!this.pool.length) { // hết chu kỳ -> chu kỳ mới
        this.pool = shuffle(this.all.filter((i) => !this.bigs.includes(i) && !this.busy.has(i)))
        if (!this.pool.length) break
      }
      this.bigs.push(this.pool.shift())
    }
  }
  redraw() { this.bigs = []; this.fill() } // dùng khi triệu hồi lại sau khi thu hồi
  select(id) { this.bigs = this.bigs.filter((i) => i !== id); this.busy.add(id); this.fill() }
  release(id) { this.busy.delete(id); this.fill() }
}
