export default function CameraIndicator({ videoRef, status }) {
  const msg = { loading: 'Đang khởi động camera và mô hình nhận diện tay…', denied: 'Hãy cho phép truy cập camera trong trình duyệt rồi tải lại trang.', error: 'Không thể mở camera hoặc tải mô hình. Kiểm tra kết nối mạng và camera.' }[status]
  return (<>
    <div className="cam"><video ref={videoRef} playsInline muted /><i className={status === 'ready' ? 'ready' : ''} /></div>
    {msg && <div className="cam-msg">{msg}</div>}
  </>)
}
