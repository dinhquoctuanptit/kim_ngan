const ITEMS = [
  { icon: '🫶', name: 'Hai tay chụm hình tim', desc: 'Mưa I LOVE U', on: ['LOVE'] },
  { icon: '🖐️', name: 'Xòe một tay', desc: 'Bung tim, hiện ảnh', on: ['EXPLODE', 'SUMMON_IMAGES', 'IMAGE_SELECTION'] },
  { icon: '👌', name: 'Ký hiệu OK', desc: 'Chọn ảnh ở giữa', on: ['IMAGE_SELECTED'] },
  { icon: '🤲', name: 'Hai tay tách / gần', desc: 'Phóng to / thu nhỏ', on: ['IMAGE_ZOOM'] },
  { icon: '✊', name: 'Nắm tay', desc: 'Thu về trái tim', on: ['GATHER'] },
  { icon: '🖕', name: 'Ngón giữa', desc: 'Ảnh đặc biệt', on: ['SPECIAL_IMAGE'] },
]
export default function GestureGuide({ state }) {
  return (
    <div className="guide">
      {ITEMS.map((g) => (
        <div key={g.name} className={'guide-item' + (g.on.includes(state) ? ' active' : '')}>
          <span className="guide-icon">{g.icon}</span>
          <span className="guide-text"><b>{g.name}</b><small>{g.desc}</small></span>
        </div>
      ))}
    </div>
  )
}
