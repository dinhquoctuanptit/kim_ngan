import { useEffect, useRef } from 'react'
const COLORS = ['#FF00CC', '#FFF5FA', '#FF1493', '#FFB6D9', '#FFC0CB']
export default function LoveEffect({ active }) {
  const box = useRef(null)
  useEffect(() => {
    if (!active) return
    const id = setInterval(() => {
      const s = document.createElement('span')
      s.textContent = 'I LOVE U'
      s.style.left = Math.random() * 95 + '%'
      s.style.fontSize = 14 + Math.random() * 40 + 'px'
      s.style.color = COLORS[(Math.random() * COLORS.length) | 0]
      s.style.animationDuration = 3 + Math.random() * 4 + 's'
      s.style.setProperty('--r', (Math.random() * 50 - 25) + 'deg')
      s.addEventListener('animationend', () => s.remove())
      box.current.appendChild(s)
    }, 90)
    return () => clearInterval(id)
  }, [active])
  return <div className="rain" ref={box} />
}
